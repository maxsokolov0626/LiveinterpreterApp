rootProject.name = "LiveInterpreter"
include(":app")
